// MainActivity with detection, vibration & sound alerts
