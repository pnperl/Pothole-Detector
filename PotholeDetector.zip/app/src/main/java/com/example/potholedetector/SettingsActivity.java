// SettingsActivity with toggles for vibration & sound
